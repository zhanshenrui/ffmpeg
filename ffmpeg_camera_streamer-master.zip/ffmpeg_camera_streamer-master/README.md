# ffmpeg_camera_streamer

本程序实现了读取PC端摄像头并进行直播的功能，并且可以添加不同的视频滤镜

This program can read from PC camera and stream it to live streaming server, you can also add different video filters to the live stream.

张晖
Hui Zhang
中国传媒大学/数字电视技术
Communication University of China/Digital Video Technology

zhanghuicuc@gmail.com
http://blog.csdn.net/nonmarking

